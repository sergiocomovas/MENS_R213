<h1>Welcome to Wikitten!</h1>
<p>
  You're looking at this page because you haven't created a <code><?php echo LIBRARY . DIRECTORY_SEPARATOR . DEFAULT_FILE ?></code> file yet.
</p>