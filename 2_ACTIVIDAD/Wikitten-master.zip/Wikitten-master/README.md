Wikitten
========

Wikitten is a small, fast, PHP wiki, and the perfect place to store your notes, code snippets, ideas, etc.

Check out the **[project website](http://wikitten.vizuina.com)** for more details and features.

[![Wikitten](http://wikitten.vizuina.com/screenshot.png)](http://wikitten.vizuina.com)
