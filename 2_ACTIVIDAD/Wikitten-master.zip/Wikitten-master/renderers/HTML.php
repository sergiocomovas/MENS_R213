<?php

function HTML($source) {
    return $source;
}